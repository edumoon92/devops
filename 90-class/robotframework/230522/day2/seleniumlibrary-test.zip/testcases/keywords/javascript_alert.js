alert(arguments[0]);
